# CTECH Cloud Academy

Static frontend (HTML/CSS/vanilla JS) + Supabase (Auth, Postgres, Edge Functions) + Razorpay (test mode).

## Folder structure
```
index.html courses.html ... (15 pages)   css/style.css   js/*.js
supabase/schema.sql  supabase/seed.sql   supabase/functions/{create-order,verify-payment}/index.ts
.env.example  package.json  README.md
```

## 1. Open in VS Code
Install [VS Code](https://code.visualstudio.com) and [Node.js LTS](https://nodejs.org). Unzip, then **File > Open Folder** and choose `ctech`. Open the terminal (Ctrl + `).

## 2. Install dependencies
There are none for the website itself. The Supabase CLI (for the Edge Functions) is installed in step 5.

## 3. Configure Supabase
1. Create a free project at supabase.com.
2. **Project Settings > API**: copy the Project URL and the `anon` public key into `js/supabase.js` (replace `YOUR_SUPABASE_URL` / `YOUR_SUPABASE_ANON_KEY`). Never use the service-role key there.
3. **Authentication > Providers > Email**: keep "Confirm email" on, set minimum password length to 8.
4. **Authentication > URL Configuration**: Site URL `http://localhost:3000`, and add `http://localhost:3000/login.html` and `http://localhost:3000/forgot-password.html` to Redirect URLs.

## 4. Apply the database schema
In Supabase **SQL Editor**, run `supabase/schema.sql`, then `supabase/seed.sql`.
The seeded courses use **placeholder fees (INR 10000)**. Change them in Admin > Courses.

## 5. Razorpay test credentials and Edge Functions
1. Create a Razorpay account, switch to **Test Mode**, and generate API keys (Settings > API Keys).
2. Install the CLI: `npm install -g supabase`, then `supabase login` and `supabase link --project-ref YOUR_PROJECT_REF`.
3. Set secrets (Supabase supplies `SUPABASE_URL`, `SUPABASE_ANON_KEY` and the service-role key to functions automatically):
   `supabase secrets set RAZORPAY_KEY_ID=rzp_test_xxx RAZORPAY_KEY_SECRET=xxx RAZORPAY_WEBHOOK_SECRET=choose_a_long_random_string`
4. Deploy: `supabase functions deploy create-order`, `supabase functions deploy verify-payment --no-verify-jwt`, and `supabase functions deploy invoice-view --no-verify-jwt`.
   (`verify-payment` checks the user token or the Razorpay signature itself, because Razorpay's webhook has no Supabase token).
5. In Razorpay **Settings > Webhooks** add `https://YOUR_PROJECT_REF.supabase.co/functions/v1/verify-payment`, use the same webhook secret, and enable `payment.captured`, `order.paid` and `payment.failed`.

`.env.example` lists the variable names for reference. Keep real values out of the frontend and out of GitHub.

## 6. Start the local server
```
npm start
```
Open http://localhost:3000. Do not open the HTML files directly (file://): auth redirects and payments need an HTTP origin.

## 7. Register and log in as a student
Register, click the verification link in the email, then log in. You land on the dashboard.

## 8. Test enrollment and payment
Open a course > Enroll Now > Pay. Use Razorpay test cards/UPI from Razorpay's docs. After success you see a confirmation, and the dashboard shows the enrollment as `paid`. If the keys are missing you will see a clear "not configured" message; no payment is simulated.

## 9. Make an admin
Register normally, then run in the SQL Editor (replace the email):
```sql
update public.profiles set role='admin' where id=(select id from auth.users where email='you@example.com');
```
Log out and in, then open `admin.html`. Admin rights come from the database role plus RLS, not from anything editable in the browser.

## 10. Troubleshooting
- **Yellow "Development mode" banner**: `js/supabase.js` still has placeholder values.
- **"Invalid login credentials"**: email not verified yet, or wrong password.
- **Verification link goes to the wrong URL**: fix the Site URL/Redirect URLs (step 3).
- **Admin page says Access denied**: the SQL in step 9 has not been run for that user.
- **Payment error "not configured"**: secrets not set or functions not deployed (step 5).
- **Course list empty**: run `seed.sql` and make sure courses are published.
- **Port in use**: `npx serve . -l 3001`.

## Still to configure (not active until you do)
Supabase project, Razorpay keys, webhook, real course fees and content, academy contact details (`CONFIG` in `js/main.js`), real instructor/testimonial/statistics content, legal text review, and a refund policy.


## 11. Razorpay verification + automatic invoice email and MSG91 SMS

This implementation extends the existing `payments`, `enrollments`, `profiles`, and `courses` schema. It creates `invoice_records` and `invoice_email_deliveries` via `supabase/migrations/202610120001_invoice_email.sql`. The MSG91 extension adds `supabase/migrations/202610120002_msg91_sms.sql`. If you have not applied the prior invoice migration yet, apply `202610120001_invoice_email.sql` first and then `202610120002_msg91_sms.sql`. If the invoice migration was already applied in the previous setup, apply only the new `202610120002_msg91_sms.sql` migration. Do not replace your original schema.

### Required secrets

Set these in Supabase; never put them in frontend JavaScript or `.env.example`:

```powershell
supabase secrets set RAZORPAY_KEY_ID=rzp_test_REPLACE_ME RAZORPAY_KEY_SECRET=REPLACE_ME RAZORPAY_WEBHOOK_SECRET=REPLACE_WITH_YOUR_RAZORPAY_WEBHOOK_SECRET RESEND_API_KEY=re_REPLACE_ME RESEND_FROM_EMAIL="CTech Cloud Academy <billing@your-verified-domain.example>" MSG91_AUTH_KEY=REPLACE_WITH_MSG91_AUTH_KEY MSG91_TEMPLATE_ID=REPLACE_WITH_APPROVED_MSG91_FLOW_TEMPLATE_ID INVOICE_LINK_SECRET=REPLACE_WITH_LONG_RANDOM_SECRET
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` are provided to Supabase Edge Functions. The sender address must be on a domain verified in Resend. Use Razorpay test keys first; use live keys only after end-to-end tests.

### Deploy

```powershell
supabase functions deploy create-order
supabase functions deploy verify-payment --no-verify-jwt
supabase functions deploy invoice-view --no-verify-jwt
```

The function accepts authenticated checkout callbacks and Razorpay webhooks. In Razorpay Dashboard > Account & Settings > Webhooks, configure the URL `https://YOUR_PROJECT_REF.supabase.co/functions/v1/verify-payment`, use the exact same webhook secret as `RAZORPAY_WEBHOOK_SECRET`, and subscribe to `payment.captured` and `payment.failed`. The function verifies the webhook signature over the raw body. A successful checkout signature alone is not enough: it also fetches the payment from Razorpay and checks order ID, amount, currency, and `captured` status.

### Invoice and duplicate prevention

On confirmed capture, the function marks the existing payment and enrollment paid, stores a stable invoice snapshot, builds a PDF attachment and HTML invoice, and sends both through Resend. It also sends an SMS confirmation through MSG91 to `profiles.phone`; the SMS contains the invoice number, amount, and a 30-day HMAC-signed invoice link served by the `invoice-view` Edge Function. The SMS flow uses `MSG91_TEMPLATE_ID` and passes `VAR1` = invoice number, `VAR2` = amount, `VAR3` = secure invoice link. Create and approve a matching MSG91 Flow/SMS template (including the required India DLT registration/template where applicable) before testing. A unique invoice per payment, separate database-backed email/SMS delivery claims, and provider idempotency keys where supported reduce duplicate sends on concurrent calls/retries. Failed deliveries are marked `failed` so a later webhook retry can try again. `processing` rows left by a hard runtime interruption should be reviewed manually before resetting; do not reset a row while a send may still be in progress.

No GSTIN is printed or implied. Have an accountant review the invoice wording and any tax/compliance requirements applicable to your business before issuing real invoices.

### Test checklist

1. Apply the migration and set all five secrets.
2. Confirm the `RESEND_FROM_EMAIL` domain is verified.
3. Use Razorpay test mode and a published course; complete a test payment.
4. Confirm `payments.status = paid` and `enrollments.status = paid`.
5. Confirm exactly one `invoice_records` row and one `invoice_email_deliveries` row with `status = sent` for the payment.
6. Confirm the email contains the HTML invoice and a readable PDF attachment. Confirm the registered mobile receives the MSG91 SMS and its signed invoice link opens the correct invoice; confirm an expired/tampered link is rejected.
7. Replay the same captured webhook and verify no second invoice email is sent.
8. Test bad checkout signatures and bad webhook signatures; both must be rejected.

### Credential safety

The uploaded `.env.example` contained credential-looking Razorpay values. They have been removed from this patched project. If those were real credentials, rotate/revoke the Razorpay API key secret and webhook secret in their dashboards immediately, then set new values as Supabase secrets.


### Fix for missing transaction / receipt notifications
The `create-order` function now checks the Supabase `payments` insert and enrollment status update before returning a Razorpay order to the frontend. Previously, the insert error was ignored, which could allow checkout to proceed without a matching `payments` row; then `verify-payment` could not find the order and invoice notifications would not run. Redeploy `create-order` after updating. The payment-success page also now logs and displays lookup errors separately from a missing row.

After deploying, test with Razorpay Test Mode. If the payment record exists but email/SMS still do not arrive, inspect `verify-payment` Edge Function logs, Resend email logs, and MSG91 API Failed Logs. Ensure `RESEND_FROM_EMAIL` uses a verified Resend domain and MSG91 template variables match the approved template.


## CTECH website content update (27 Oct 2026)

- Homepage includes workshop overview (₹499 each), hybrid-learning enquiry, trainer names supplied by the academy, academy-reported training milestones, and brochure downloads.
- Seven brochure PDFs are in `assets/brochures/`.
- `supabase/migrations/202610270001_featured_programs.sql` adds/updates six featured programs at ₹50,000 each.
- Run the migration in the Supabase SQL Editor before expecting the featured programs to appear in the database-driven course catalogue. Back up the database first.
- Workshop registration currently starts via WhatsApp; the existing Razorpay flow is course/enrollment-based and has not been represented as a working workshop checkout.
- Academy address and email were not supplied, so the site asks visitors to confirm them. Trainer qualifications/photos, genuine testimonials, certification details, and formal employer partnerships were not invented.
- Review all brochure text, course syllabus, duration, fees, and hybrid arrangements before publishing.

## Workshop Razorpay checkout (₹499 per workshop)

The homepage workshop cards use the separate `create-workshop-order` and `verify-workshop-payment` Supabase Edge Functions. Before enabling live workshop payments:

1. Run `supabase/migrations/202610270002_workshop_payments.sql` in the Supabase SQL Editor (after confirming the existing `public.is_admin()` and `public.touch()` helper functions are present).
2. Ensure Supabase Edge Function secrets are configured: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `SUPABASE_URL`, `SUPABASE_ANON_KEY` (or `SUPABASE_PUBLISHABLE_KEY`), and `SUPABASE_SERVICE_ROLE_KEY`. Never place the Razorpay secret or service-role key in frontend JavaScript.
3. Deploy both functions from the project root with the Supabase CLI:
   - `supabase functions deploy create-workshop-order`
   - `supabase functions deploy verify-workshop-payment`
4. Test with Razorpay test-mode keys and a logged-in student account first. Only switch to live keys after successful test orders, server-side signature verification, and database status updates.
5. The server fixes the workshop amount at ₹499 (49,900 paise); the browser cannot choose the amount. Successful checkout is marked paid only after signature verification and Razorpay API status/amount/currency checks.

Workshop dates and availability still need to be confirmed by the academy. Payment alone does not select a date or guarantee a seat for a specific session.


import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

export const SUPABASE_URL =
  "https://tmihufpfreskvvwtniaj.supabase.co";

export const SUPABASE_ANON_KEY =
  "sb_publishable_CQVd8Cv-sZsdUwBJWXfF0A_ijJeEgSw";

export const configured =
  !SUPABASE_URL.startsWith("YOUR_") &&
  !SUPABASE_ANON_KEY.startsWith("YOUR_");

export const sb = createClient(
  configured
    ? SUPABASE_URL
    : "https://placeholder.supabase.co",
  configured
    ? SUPABASE_ANON_KEY
    : "placeholder",
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
  }
);

export async function getUser() {
  const { data, error } = await sb.auth.getSession();

  if (error) {
    console.error("Unable to get session");
    return null;
  }

  return data.session?.user || null;
}

export async function getProfile(id) {
  const { data, error } = await sb
    .from("profiles")
    .select("*")
    .eq("id", id)
    .single();

  if (error) {
    console.error("Unable to retrieve profile");
    return null;
  }

  return data;
}

export async function requireAuth() {
  const user = await getUser();

  if (!user) {
    location.href =
      "login.html?next=" +
      encodeURIComponent(
        location.pathname.split("/").pop() + location.search
      );

    return new Promise(() => {});
  }

  return user;
}

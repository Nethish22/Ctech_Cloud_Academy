import { sb, requireAuth } from './supabase.js';
import { $, esc, inr, param, setLoading, showMsg } from './main.js';
import { startPayment } from './payment.js';

export async function init() {
  const user = await requireAuth(), box = $('#enroll-box'), id = param('course');
  if (!id) { box.innerHTML = '<p class="empty">No course selected. <a href="courses.html">Browse courses</a></p>'; return; }

  // price shown here is for display only; the server recalculates it from the database
  const { data: c } = await sb.from('courses').select('*').eq('id', id).eq('is_published', true).maybeSingle();
  if (!c) { box.innerHTML = '<p class="empty">This course is not available.</p>'; return; }

  const { data: ex } = await sb.from('enrollments').select('status').eq('user_id', user.id).eq('course_id', id).maybeSingle();
  const total = c.fee_inr - c.discount_inr, paid = ex?.status === 'paid';

  box.innerHTML = `<h2>${esc(c.name)}</h2><p>${esc(c.category)} · ${esc(c.duration)}</p>
<table><tr><td>Course fee</td><td>${inr(c.fee_inr)}</td></tr><tr><td>Discount</td><td>- ${inr(c.discount_inr)}</td></tr><tr><th>Total</th><th>${inr(total)}</th></tr></table>
<label for="mode">Learning mode</label><select id="mode"><option value="online">Online</option><option value="offline">Offline</option></select>
<button class="btn btn-primary" id="pay" style="margin-top:18px" ${paid ? 'disabled' : ''}>${paid ? 'Already enrolled' : 'Pay ' + inr(total) + ' with Razorpay'}</button>
<div id="enroll-msg" role="status"></div>`;

  $('#pay').onclick = async e => {
    const b = e.currentTarget, msg = $('#enroll-msg');
    setLoading(b, true, 'Saving enrollment…');
    try {
      // 1) make sure a pending enrollment exists (saved even if payment is not set up yet)
      if (!ex) {
        const { error } = await sb.from('enrollments').insert({ user_id: user.id, course_id: id, learning_mode: $('#mode').value, status: 'pending' });
        if (error && !/duplicate|unique/i.test(error.message)) throw new Error('Could not save enrollment: ' + error.message);
      }
      // 2) open payment through the secure backend
      setLoading(b, true, 'Preparing checkout…');
      await startPayment(id, $('#mode').value);
      setLoading(b, false);
    } catch (err) {
      setLoading(b, false);
      console.error('Payment start failed:', err);
      let m = err.message || 'Something went wrong';
      if (/not configured/i.test(m)) m = 'Your enrollment is saved as pending. Razorpay keys are not set yet.';
      else m = 'Payment could not start: ' + m;
      showMsg(msg, m, false);
    }
  };
}
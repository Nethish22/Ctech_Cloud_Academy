import { sb, requireAuth, getProfile } from './supabase.js';
import { $, esc, inr, toast, showMsg, link } from './main.js';

const badge = s => `<span class="badge ${esc(s)}">${esc(s)}</span>`;

function receipt(p) {
  const h = `<html><head><title>Receipt</title></head><body style="font-family:sans-serif;padding:30px"><h2>CTECH Cloud Academy — Payment Receipt</h2><p>Course: ${esc(p.enrollments?.courses?.name)}</p><p>Amount: ${inr(p.amount_paise / 100)}</p><p>Transaction: ${esc(p.razorpay_payment_id)}</p><p>Order: ${esc(p.razorpay_order_id)}</p><p>Date: ${new Date(p.updated_at).toLocaleString()}</p></body></html>`;
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([h], { type: 'text/html' }));
  a.download = 'receipt-' + p.razorpay_payment_id + '.html';
  a.click();
}

export async function init() {
  const user = await requireAuth();
  const prof = await getProfile(user.id);
  $('#welcome').textContent = 'Welcome, ' + (prof?.first_name || 'Student');

  const f = $('#profile-form');
  ['first_name', 'last_name', 'phone', 'learning_mode'].forEach(k => f[k].value = prof?.[k] || '');
  $('#p-email').textContent = user.email;

  f.addEventListener('submit', async e => {
    e.preventDefault();
    const phone = f.phone.value.replace(/[\s-]/g, '');
    if (!/^(\+91)?[6-9]\d{9}$/.test(phone)) return showMsg($('#p-msg'), 'Enter a valid mobile number', false);
    const { error } = await sb.from('profiles').update({
      first_name: f.first_name.value.trim(),
      last_name: f.last_name.value.trim(),
      phone: f.phone.value.trim(),
      learning_mode: f.learning_mode.value
    }).eq('id', user.id);
    showMsg($('#p-msg'), error ? error.message : 'Profile updated', !error);
  });

  const [en, pa] = await Promise.all([
    sb.from('enrollments').select('*,courses(name,duration,delivery_mode,slug)').order('created_at', { ascending: false }),
    sb.from('payments').select('*,enrollments(courses(name))').order('created_at', { ascending: false })
  ]);

  $('#enrollments').innerHTML = en.data?.length
    ? en.data.map(e => `<div class="card" style="margin-bottom:12px"><h3>${esc(e.courses?.name)}</h3><p>${esc(e.courses?.duration)} · ${esc(e.learning_mode || e.courses?.delivery_mode)}</p><p>Enrollment: ${badge(e.status)}</p>${e.status === 'paid'
        ? `<a class="btn btn-primary btn-sm" href="${link('course-details.html', 'slug', e.courses?.slug)}">Open course</a>`
        : `<a class="btn btn-ghost btn-sm" href="${link('enroll.html', 'course', e.course_id)}">Complete payment</a>`}</div>`).join('')
    : '<p class="empty">You have not enrolled in any course yet. <a href="courses.html">Browse courses</a></p>';

  const rows = pa.data || [];
  $('#payments').innerHTML = rows.length
    ? `<div class="tablewrap"><table><tr><th>Date</th><th>Course</th><th>Amount</th><th>Status</th><th>Reference</th><th></th></tr>${rows.map((p, i) => `<tr><td>${new Date(p.created_at).toLocaleDateString()}</td><td>${esc(p.enrollments?.courses?.name)}</td><td>${inr(p.amount_paise / 100)}</td><td>${badge(p.status)}</td><td>${esc(p.razorpay_payment_id || '—')}</td><td>${p.status === 'paid' ? `<button class="btn btn-ghost btn-sm" data-r="${i}">Receipt</button>` : ''}</td></tr>`).join('')}</table></div>`
    : '<p class="empty">No transactions yet.</p>';

  $('#payments').addEventListener('click', e => {
    const b = e.target.closest('[data-r]');
    if (b) receipt(rows[b.dataset.r]);
  });
  $('#dash-logout').onclick = async () => { await sb.auth.signOut(); location.href = 'index.html'; };
}
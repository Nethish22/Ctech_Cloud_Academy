import { sb, getUser } from './supabase.js';
import { toast, setLoading } from './main.js';

const loadCheckout = () => new Promise((resolve, reject) => {
  if (window.Razorpay) return resolve();
  const existing = document.querySelector('script[data-razorpay-checkout]');
  if (existing) { existing.addEventListener('load', resolve, { once: true }); existing.addEventListener('error', () => reject(new Error('Could not load Razorpay Checkout.')), { once: true }); return; }
  const script = document.createElement('script');
  script.src = 'https://checkout.razorpay.com/v1/checkout.js';
  script.dataset.razorpayCheckout = 'true';
  script.onload = resolve; script.onerror = () => reject(new Error('Could not load Razorpay Checkout.'));
  document.head.appendChild(script);
});

async function invoke(name, body) {
  const { data, error } = await sb.functions.invoke(name, { body });
  if (error) {
    let message = error.message || 'Request failed';
    try { const detail = await error.context?.json(); message = detail?.error || detail?.message || message; } catch { /* keep original */ }
    throw new Error(message);
  }
  return data;
}

async function payForWorkshop(button) {
  const user = await getUser();
  if (!user) {
    location.href = 'login.html?next=' + encodeURIComponent('index.html#workshops');
    return;
  }
  setLoading(button, true, 'Preparing secure checkout…');
  try {
    const order = await invoke('create-workshop-order', { workshop_slug: button.dataset.workshopPay });
    await loadCheckout();
    const checkout = new window.Razorpay({
      key: order.key_id,
      amount: order.amount,
      currency: order.currency || 'INR',
      order_id: order.order_id,
      name: 'CTECH Cloud Academy',
      description: order.workshop_title,
      prefill: { email: user.email || '' },
      theme: { color: '#1687FF' },
      handler: async response => {
        setLoading(button, true, 'Verifying payment…');
        try {
          const verified = await invoke('verify-workshop-payment', response);
          if (!verified.captured) throw new Error('Payment is not captured yet. Please check your payment status before trying again.');
          button.disabled = true;
          button.textContent = 'Payment confirmed ✓';
          toast(`Payment confirmed for ${verified.workshop_title}. Contact the academy to confirm the workshop schedule.`, 'success');
          window.alert(`Payment successful!\nWorkshop: ${verified.workshop_title}\nAmount: ₹499\nPayment ID: ${response.razorpay_payment_id}\n\nYour payment has been verified. Please contact CTECH Cloud Academy to confirm the workshop date and joining details.`);
        } catch (error) {
          console.error('Workshop payment verification failed:', error);
          toast(error.message || 'Payment verification failed. If money was deducted, contact the academy with your payment ID.', 'error');
          setLoading(button, false);
        }
      },
      modal: { ondismiss: () => { setLoading(button, false); toast('Checkout closed. You can retry when ready.', 'info'); } }
    });
    checkout.on('payment.failed', response => {
      setLoading(button, false);
      const reason = response?.error?.description || 'Payment was not completed.';
      toast(reason + ' You can retry the workshop payment.', 'error');
    });
    setLoading(button, false);
    checkout.open();
  } catch (error) {
    console.error('Could not start workshop payment:', error);
    setLoading(button, false);
    toast(error.message || 'Could not start payment. Please try again.', 'error');
  }
}

document.addEventListener('click', event => {
  const button = event.target.closest('[data-workshop-pay]');
  if (!button || button.disabled) return;
  payForWorkshop(button);
});

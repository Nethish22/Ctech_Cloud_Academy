import { sb, requireAuth, getProfile } from './supabase.js';
import { $, $$, esc, inr, toast, CATS } from './main.js';
const get = (o, p) => p.split('.').reduce((a, k) => a?.[k], o);
const STAT = ['pending', 'payment_pending', 'paid', 'failed', 'cancelled', 'refunded'], ENQ = ['new', 'contacted', 'closed'];
const TABS = {
  students: { label: 'Students', q: () => sb.from('profiles').select('*').order('created_at', { ascending: false }), cols: [['first_name', 'First'], ['last_name', 'Last'], ['email', 'Email'], ['phone', 'Phone'], ['learning_mode', 'Mode'], ['role', 'Role'], ['created_at', 'Joined']] },
  courses: { label: 'Courses', q: () => sb.from('courses').select('*').order('name'), cols: [['name', 'Name'], ['category', 'Category'], ['fee_inr', 'Fee (INR)'], ['discount_inr', 'Discount'], ['is_published', 'Published']] },
  enrollments: { label: 'Enrollments', q: () => sb.from('enrollments').select('*,profiles(first_name,last_name,email),courses(name)').order('created_at', { ascending: false }), cols: [['profiles.first_name', 'Student'], ['profiles.email', 'Email'], ['courses.name', 'Course'], ['status', 'Status'], ['created_at', 'Created']] },
  payments: { label: 'Payments', q: () => sb.from('payments').select('*,profiles(first_name,last_name),enrollments(courses(name))').order('created_at', { ascending: false }), cols: [['profiles.first_name', 'Student'], ['enrollments.courses.name', 'Course'], ['amount_paise', 'Amount (INR)'], ['status', 'Status'], ['razorpay_order_id', 'Order'], ['razorpay_payment_id', 'Payment'], ['created_at', 'Date']] },
  enquiries: { label: 'Enquiries', q: () => sb.from('contact_enquiries').select('*').order('created_at', { ascending: false }), cols: [['full_name', 'Name'], ['email', 'Email'], ['phone', 'Phone'], ['subject', 'Subject'], ['message', 'Message'], ['status', 'Status'], ['created_at', 'Date']] }
};
let tab = 'students', rows = [];
const sel = (opts, v, kind, id) => `<select data-kind="${kind}" data-id="${id}">${opts.map(o => `<option ${o === v ? 'selected' : ''}>${o}</option>`).join('')}</select>`;
function cell(r, [p]) {
  const v = get(r, p);
  if (p === 'created_at') return new Date(v).toLocaleString();
  if (p === 'amount_paise') return inr(v / 100);
  if (tab === 'enrollments' && p === 'status') return sel(STAT, v, 'enr', r.id);
  if (tab === 'enquiries' && p === 'status') return sel(ENQ, v, 'enq', r.id);
  if (p === 'is_published') return v ? 'Yes' : 'No';
  return esc(v ?? '');
}
function view() {
  const t = $('#search').value.toLowerCase(), cols = TABS[tab].cols;
  const r = rows.filter(x => !t || JSON.stringify(x).toLowerCase().includes(t)); $('#shown').textContent = r.length + ' record(s)';
  const act = tab === 'courses' ? '<th>Actions</th>' : '';
  $('#table').innerHTML = r.length ? `<table><tr>${cols.map(c => `<th>${c[1]}</th>`).join('')}${act}</tr>${r.map(x => `<tr>${cols.map(c => `<td>${cell(x, c)}</td>`).join('')}${tab === 'courses' ? `<td><button class="btn btn-ghost btn-sm" data-act="edit" data-id="${x.id}">Edit</button> <button class="btn btn-ghost btn-sm" data-act="toggle" data-id="${x.id}">${x.is_published ? 'Deactivate' : 'Publish'}</button></td>` : ''}</tr>`).join('')}</table>` : '<p class="empty">No records found.</p>';
  $$('#table tr').length; window.__view = r;
}
async function load() {
  $('#table').innerHTML = '<p class="empty"><span class="spin"></span> Loading…</p>';
  const { data, error } = await TABS[tab].q(); if (error) { toast(error.message, 'error'); rows = []; } else rows = data || [];
  $('#add-course').hidden = tab !== 'courses'; view();
}
function csv() {
  const cols = TABS[tab].cols, esc2 = v => '"' + String(v ?? '').replace(/"/g, '""').replace(/^([=+\-@])/, "'$1") + '"';
  const out = [cols.map(c => esc2(c[1])).join(','), ...(window.__view || []).map(r => cols.map(c => esc2(c[0] === 'amount_paise' ? get(r, c[0]) / 100 : get(r, c[0]))).join(','))].join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([out], { type: 'text/csv' })); a.download = tab + '.csv'; a.click();
}
function openCourse(c = {}) {
  const f = $('#course-form'); f.reset(); f.dataset.id = c.id || '';
  $('#c-cat').innerHTML = CATS.map(x => `<option>${esc(x)}</option>`).join('');
  ['name', 'slug', 'category', 'description', 'duration', 'delivery_mode', 'skill_level', 'prerequisites', 'projects', 'fee_inr', 'discount_inr'].forEach(k => { if (f[k]) f[k].value = c[k] ?? (k === 'discount_inr' ? 0 : ''); });
  f.is_published.checked = !!c.is_published; $('#course-dlg').showModal();
}
export async function init() {
  const user = await requireAuth(), prof = await getProfile(user.id);
  if (prof?.role !== 'admin') { document.querySelector('main').innerHTML = '<section class="wrap"><p class="empty">Access denied. Administrator account required.</p></section>'; return; } // real enforcement is RLS
  $('#admin-app').hidden = false;
  $('#tabs').innerHTML = Object.entries(TABS).map(([k, v]) => `<button class="btn btn-ghost btn-sm" data-tab="${k}">${v.label}</button>`).join('');
  const mark = () => $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab)); mark();
  $('#tabs').onclick = e => { const b = e.target.closest('[data-tab]'); if (b) { tab = b.dataset.tab; $('#search').value = ''; mark(); load(); } };
  $('#search').oninput = view; $('#export').onclick = csv; $('#add-course').onclick = () => openCourse();
  $('#table').addEventListener('change', async e => {
    const s = e.target.closest('select[data-kind]'); if (!s) return;
    const t = s.dataset.kind === 'enr' ? 'enrollments' : 'contact_enquiries';
    const { error } = await sb.from(t).update({ status: s.value }).eq('id', s.dataset.id);
    toast(error ? error.message : 'Status updated (logged)', error ? 'error' : 'success'); if (error) load();
  });
  $('#table').addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b) return; const c = rows.find(r => r.id === b.dataset.id);
    if (b.dataset.act === 'edit') openCourse(c);
    else { const { error } = await sb.from('courses').update({ is_published: !c.is_published }).eq('id', c.id); toast(error ? error.message : 'Course updated', error ? 'error' : 'success'); load(); }
  });
  $('#cancel-course').onclick = () => $('#course-dlg').close();
  $('#course-form').addEventListener('submit', async e => {
    e.preventDefault(); const f = e.target, id = f.dataset.id;
    const d = { name: f.name.value.trim(), slug: f.slug.value.trim().toLowerCase().replace(/[^a-z0-9-]+/g, '-'), category: f.category.value, description: f.description.value, duration: f.duration.value, delivery_mode: f.delivery_mode.value, skill_level: f.skill_level.value, prerequisites: f.prerequisites.value, projects: f.projects.value, fee_inr: parseInt(f.fee_inr.value, 10), discount_inr: parseInt(f.discount_inr.value || 0, 10), is_published: f.is_published.checked };
    const { error } = id ? await sb.from('courses').update(d).eq('id', id) : await sb.from('courses').insert(d);
    if (error) return toast(error.message, 'error'); $('#course-dlg').close(); toast('Course saved', 'success'); load();
  });
  load();
}

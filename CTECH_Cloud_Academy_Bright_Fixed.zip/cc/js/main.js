import { sb, getUser, configured } from './supabase.js';
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const inr = n => '₹' + Number(n).toLocaleString('en-IN');
export const CONFIG = { email: 'Contact us on WhatsApp for the current academy email', phone: '+91 94818 52969', whatsapp: '+91 94818 52969', address: 'Please contact the academy to confirm the current training address' };
export const CATS = ['Data Analytics', 'Data Engineering', 'Data Science & AI/ML', 'DevOps Engineering', 'Forward Deployed Engineer', 'Full Stack Web Development', 'Cloud Computing', 'AI & Machine Learning', 'Full-Stack & Technology Stacks'];
export function toast(msg, type = 'info') { const t = document.createElement('div'); t.className = 'toast ' + type; t.textContent = msg; $('#toasts').append(t); setTimeout(() => t.remove(), 5500); }
export function setLoading(b, on, txt) { if (!b) return; if (on) { b.dataset.t = b.textContent; b.disabled = true; b.innerHTML = '<span class="spin"></span> ' + (txt || 'Please wait…'); } else { b.disabled = false; b.textContent = b.dataset.t || b.textContent; } }
export function animateCount(el, n) { if (matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = n; return; } const s = performance.now(); const f = t => { const p = Math.min((t - s) / 900, 1); el.textContent = Math.round(n * p); if (p < 1) requestAnimationFrame(f); }; requestAnimationFrame(f); }

// Reads a value from ?key=value OR #key=value (the # copy survives servers that strip the query string)
export const param = k => new URLSearchParams(location.search).get(k) || new URLSearchParams(location.hash.slice(1)).get(k);
// Builds a link that carries the value in both places
export const link = (page, k, v) => { const e = encodeURIComponent(v); return `${page}?${k}=${e}#${k}=${e}`; };

export function showMsg(el, text, ok) { el.className = 'msg ' + (ok ? 'ok' : 'bad'); el.textContent = text; }

async function chrome() {
  const u = await getUser();
  const cats = CATS.map(c => `<li><a href="${link('courses.html', 'cat', c)}">${esc(c)}</a></li>`).join('');
  $('#site-header').innerHTML = `<div class="wrap nav"><a class="logo" href="index.html" aria-label="CTECH Cloud Academy home"><img src="assets/logo.png" alt="CTECH Cloud Academy" height="46"></a><button class="burger" aria-label="Toggle menu" aria-expanded="false">☰</button><nav id="nav"><a href="index.html">Home</a><div class="dd"><a href="courses.html" aria-haspopup="true">Courses ▾</a><ul>${cats}<li><a href="courses.html">All courses</a></li></ul></div><a href="about.html">About Us</a><a href="index.html#workshops">Workshops</a><a href="index.html#brochures">Brochures</a><a href="contact.html">Contact</a>${u ? '<a href="dashboard.html">Dashboard</a><button class="btn btn-ghost" id="logout">Logout</button>' : '<a href="login.html">Student Login</a><a class="btn btn-primary" href="register.html">Register Now</a>'}</nav></div>`;
  $('#site-footer').innerHTML = `<div class="wrap"><div class="fgrid"><div><h3>CTECH Cloud Academy</h3><p>Professional training in data, cloud, AI and full-stack technologies.</p></div><div><h3>Courses</h3><ul>${cats}</ul></div><div><h3>Company</h3><ul><li><a href="about.html">About Us</a></li><li><a href="contact.html">Contact</a></li><li><a href="privacy-policy.html">Privacy Policy</a></li><li><a href="terms.html">Terms</a></li></ul></div></div><p class="copy">© ${new Date().getFullYear()} CTECH Cloud Academy. All rights reserved.</p></div>`;
  if (!configured) { const b = document.createElement('div'); b.className = 'banner'; b.textContent = 'Development mode: add your Supabase URL and anon key in js/supabase.js to enable live data, login and payments.'; document.body.prepend(b); }
  $('.burger').onclick = e => { const o = $('#nav').classList.toggle('open'); e.currentTarget.setAttribute('aria-expanded', o); };
  const lo = $('#logout'); if (lo) lo.onclick = async () => { await sb.auth.signOut(); location.href = 'index.html'; };
}
function reveal() {
  const els = $$('.reveal'); if (!('IntersectionObserver' in window)) return els.forEach(e => e.classList.add('in'));
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 });
  els.forEach(e => io.observe(e));
}
document.addEventListener('click', e => { const b = e.target.closest('[data-toggle-pw]'); if (!b) return; const i = b.parentElement.querySelector('input'); const show = i.type === 'password'; i.type = show ? 'text' : 'password'; b.textContent = show ? 'Hide' : 'Show'; });

const MAP = { index: 'courses', courses: 'courses', 'course-details': 'courses', register: 'auth', login: 'auth', 'forgot-password': 'auth', enroll: 'enrollment', 'payment-success': 'payment', 'payment-failed': 'payment', dashboard: 'dashboard', admin: 'admin', contact: 'contact' };
const page = document.body.dataset.page;

// boot() is intentionally NOT awaited at top level (avoids a circular-import deadlock)
async function boot() {
  await chrome(); reveal();
  if (!MAP[page]) return;
  try {
    const m = await import('./' + MAP[page] + '.js');
    await m.init?.(page);
  } catch (e) {
    console.error(e);
    const msg = !configured
      ? 'Supabase is not configured. Add your URL and anon key in js/supabase.js.'
      : 'Could not load data: ' + (e.message || e) + ' (did you run setup.sql?)';
    $$('.empty .spin').forEach(s => { s.parentElement.textContent = msg; });
    toast(msg, 'error');
  }
}
boot();
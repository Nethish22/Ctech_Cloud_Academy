import { sb } from './supabase.js';
import { $, CONFIG, esc, setLoading, showMsg } from './main.js';
import { fetchCourses } from './courses.js';
export async function init() {
  const f = $('#contact-form'), msg = $('#form-msg');
  $('#contact-info').innerHTML = `<p>Email: ${esc(CONFIG.email)}</p><p>Phone: ${esc(CONFIG.phone)}</p><p>WhatsApp: ${esc(CONFIG.whatsapp)}</p><p>Address: ${esc(CONFIG.address)}</p>`;
  try { $('#course').innerHTML += (await fetchCourses()).map(c => `<option>${esc(c.name)}</option>`).join(''); } catch { /* optional */ }
  f.addEventListener('submit', async e => {
    e.preventDefault(); const v = Object.fromEntries(new FormData(f));
    if (v.website) return; // honeypot: bots fill hidden field
    if (Date.now() - Number(localStorage.getItem('ctech_last_enq') || 0) < 30000) return showMsg(msg, 'Please wait a moment before sending another message.', false);
    if (v.full_name.trim().length < 2 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v.email) || v.message.trim().length < 5) return showMsg(msg, 'Please fill in your name, a valid email and a message.', false);
    if (v.phone && !/^(\+91)?[6-9]\d{9}$/.test(v.phone.replace(/[\s-]/g, ''))) return showMsg(msg, 'Enter a valid mobile number or leave it blank.', false);
    const b = $('#submit'); setLoading(b, true, 'Sending…');
    const { error } = await sb.from('contact_enquiries').insert({ full_name: v.full_name.trim(), email: v.email.trim(), phone: v.phone || null, course_interest: v.course || null, learning_mode: v.mode || null, subject: v.subject.trim().slice(0, 150), message: v.message.trim().slice(0, 2000) });
    setLoading(b, false);
    if (error) return showMsg(msg, 'Could not send your message. Please try again later.', false);
    localStorage.setItem('ctech_last_enq', Date.now()); showMsg(msg, 'Thank you! We have received your enquiry and will get back to you.', true); f.reset();
  });
}

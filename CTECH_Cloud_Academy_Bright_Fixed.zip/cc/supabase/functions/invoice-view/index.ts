import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const env = (key: string) => { const v = Deno.env.get(key); if (!v) throw new Error(`Missing required server secret: ${key}`); return v; };
async function hmac(secret: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg)));
  return [...sig].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function safeEq(a: string, b: string) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
const esc = (s: unknown) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
const inr = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(paise / 100);
Deno.serve(async (req) => {
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405 });
  try {
    const url = new URL(req.url); const id = url.searchParams.get("id") ?? ""; const expiresRaw = url.searchParams.get("expires") ?? ""; const token = url.searchParams.get("token") ?? "";
    const expires = Number(expiresRaw);
    if (!/^[0-9a-f-]{36}$/i.test(id) || !Number.isSafeInteger(expires) || expires < Math.floor(Date.now() / 1000) || expires > Math.floor(Date.now() / 1000) + 31 * 24 * 60 * 60 || !/^[0-9a-f]{64}$/i.test(token)) return new Response("Invalid or expired invoice link", { status: 403 });
    if (!safeEq(await hmac(env("INVOICE_LINK_SECRET"), `${id}.${expires}`), token)) return new Response("Invalid or expired invoice link", { status: 403 });
    const admin = createClient(env("SUPABASE_URL"), env("SUPABASE_SERVICE_ROLE_KEY"));
    const { data: i, error } = await admin.from("invoice_records").select("invoice_number,issued_at,razorpay_payment_id,customer_name,customer_email,course_name,amount_paise,currency").eq("id", id).single();
    if (error || !i) return new Response("Invoice not found", { status: 404 });
    const date = new Date(i.issued_at).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "Asia/Kolkata" });
    const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Invoice ${esc(i.invoice_number)}</title><style>body{font:16px Arial,sans-serif;background:#f4f7fb;color:#172033;padding:20px}.sheet{max-width:760px;margin:auto;background:white;padding:32px;border-radius:12px}header{border-bottom:2px solid #1687ff;padding-bottom:20px}table{width:100%;border-collapse:collapse;margin-top:28px}th,td{text-align:left;padding:14px;border-bottom:1px solid #e5eaf0}th:last-child,td:last-child{text-align:right}.total{text-align:right;font-size:20px;font-weight:bold;margin-top:24px}.muted{color:#667085;font-size:13px}</style></head><body><main class="sheet"><header><h1>CTech Cloud Academy</h1><p>Payment invoice / receipt</p><b>Invoice ${esc(i.invoice_number)}</b><p>${esc(date)}</p></header><h2>Bill to</h2><p>${esc(i.customer_name || "Student")}<br>${esc(i.customer_email)}</p><table><thead><tr><th>Description</th><th>Payment reference</th><th>Amount</th></tr></thead><tbody><tr><td>${esc(i.course_name)}<br><span class="muted">Course enrollment</span></td><td>${esc(i.razorpay_payment_id)}</td><td>${esc(inr(i.amount_paise))}</td></tr></tbody></table><p class="total">Total paid: ${esc(inr(i.amount_paise))}</p><p>Payment status: Paid</p><p class="muted">Generated electronically by CTech Cloud Academy. No GSTIN is stated or implied. Please retain this invoice for your records.</p><button onclick="window.print()">Print / Save as PDF</button></main></body></html>`;
    return new Response(html, { status: 200, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'" } });
  } catch (e) { console.error("invoice-view failed", e); return new Response("Unable to load invoice", { status: 500 }); }
});

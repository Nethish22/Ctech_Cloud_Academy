import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { PDFDocument, StandardFonts, rgb } from "npm:pdf-lib@1.17.1";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-razorpay-signature", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });
const env = (key: string) => { const v = Deno.env.get(key); if (!v) throw new Error(`Missing required server secret: ${key}`); return v; };
async function hmac(secret: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg)));
  return [...sig].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function safeEq(a: string, b: string) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }
const esc = (s: unknown) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
const inr = (paise: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(paise / 100);
const pdfInr = (paise: number) => inr(paise).replace(/^₹\s?/, "INR ");

type Invoice = { id: string; invoice_number: string; issued_at: string; payment_id: string; razorpay_payment_id: string; customer_name: string; customer_email: string; course_name: string; amount_paise: number; currency: string };
function invoiceHtml(i: Invoice) {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Invoice ${esc(i.invoice_number)}</title><style>body{font:15px Arial,sans-serif;color:#172033;margin:0;padding:24px;background:#f4f7fb}.sheet{max-width:760px;margin:auto;background:white;padding:36px;border:1px solid #e3e8ef;border-radius:12px}.top{display:flex;justify-content:space-between;gap:20px;border-bottom:2px solid #1687ff;padding-bottom:20px}h1{margin:0 0 6px;font-size:26px}h2{font-size:18px}.muted{color:#667085}.label{font-size:12px;text-transform:uppercase;color:#667085;letter-spacing:.06em}table{width:100%;border-collapse:collapse;margin-top:28px}th,td{padding:14px;border-bottom:1px solid #e5eaf0;text-align:left}th:last-child,td:last-child{text-align:right}.total{font-size:20px;font-weight:bold;text-align:right;margin-top:24px}.note{margin-top:34px;color:#667085;font-size:12px}@media(max-width:520px){.sheet{padding:20px}.top{display:block}.meta{margin-top:18px}}</style></head><body><main class="sheet"><div class="top"><div><h1>CTech Cloud Academy</h1><div class="muted">Payment receipt / Invoice</div></div><div class="meta"><div class="label">Invoice number</div><strong>${esc(i.invoice_number)}</strong><p><span class="label">Date</span><br>${esc(new Date(i.issued_at).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "Asia/Kolkata" }))}</p></div></div><h2>Bill to</h2><div>${esc(i.customer_name || "Student")}<br>${esc(i.customer_email)}</div><table><thead><tr><th>Description</th><th>Payment reference</th><th>Amount</th></tr></thead><tbody><tr><td>${esc(i.course_name)}<br><span class="muted">Course enrollment</span></td><td>${esc(i.razorpay_payment_id)}</td><td>${esc(inr(i.amount_paise))}</td></tr></tbody></table><div class="total">Total paid: ${esc(inr(i.amount_paise))}</div><p class="muted">Payment status: Paid</p><div class="note">Generated electronically by CTech Cloud Academy. No GSTIN was provided; no GST registration claim is made on this invoice. Please retain this invoice for your records.</div></main></body></html>`;
}
async function invoicePdf(i: Invoice): Promise<Uint8Array> {
  const pdf = await PDFDocument.create(); const page = pdf.addPage([595.28, 841.89]);
  const regular = await pdf.embedFont(StandardFonts.Helvetica); const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const blue = rgb(0.08, 0.53, 1); const dark = rgb(0.09, 0.13, 0.2); const grey = rgb(0.38, 0.42, 0.48);
  page.drawText("CTech Cloud Academy", { x: 48, y: 780, size: 22, font: bold, color: blue });
  page.drawText("PAYMENT RECEIPT / INVOICE", { x: 48, y: 750, size: 12, font: bold, color: dark });
  page.drawLine({ start: { x: 48, y: 733 }, end: { x: 547, y: 733 }, thickness: 2, color: blue });
  const lines: [string, string][] = [["Invoice number", i.invoice_number], ["Invoice date", new Date(i.issued_at).toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata" })], ["Customer", i.customer_name || "Student"], ["Email", i.customer_email], ["Course", i.course_name], ["Payment ID", i.razorpay_payment_id]];
  let y = 695; for (const [label, value] of lines) { page.drawText(label, { x: 48, y, size: 10, font: bold, color: grey }); page.drawText(value.slice(0, 75), { x: 170, y, size: 11, font: regular, color: dark }); y -= 30; }
  page.drawLine({ start: { x: 48, y: y - 2 }, end: { x: 547, y: y - 2 }, thickness: 1, color: rgb(.88,.9,.93) }); y -= 36;
  page.drawText("Description", { x: 48, y, size: 10, font: bold, color: grey }); page.drawText("Amount", { x: 440, y, size: 10, font: bold, color: grey }); y -= 28;
  page.drawText((i.course_name || "Course enrollment").slice(0, 60), { x: 48, y, size: 11, font: regular, color: dark }); page.drawText(pdfInr(i.amount_paise), { x: 440, y, size: 11, font: bold, color: dark }); y -= 48;
  page.drawText("TOTAL PAID", { x: 330, y, size: 11, font: bold, color: dark }); page.drawText(pdfInr(i.amount_paise), { x: 440, y, size: 15, font: bold, color: blue });
  page.drawText("Payment status: Paid", { x: 48, y: 180, size: 11, font: bold, color: dark });
  page.drawText("Generated electronically by CTech Cloud Academy.", { x: 48, y: 145, size: 9, font: regular, color: grey });
  page.drawText("No GSTIN was provided; this invoice makes no GST registration claim.", { x: 48, y: 130, size: 9, font: regular, color: grey });
  page.drawText("Please retain this invoice for your records.", { x: 48, y: 115, size: 9, font: regular, color: grey });
  return await pdf.save();
}
function normalizeIndianMobile(raw: unknown): string {
  const digits = String(raw ?? "").replace(/\D/g, "");
  if (/^[6-9]\d{9}$/.test(digits)) return `91${digits}`;
  if (/^91[6-9]\d{9}$/.test(digits)) return digits;
  throw new Error("Student profile phone must be a valid Indian mobile number with or without +91");
}
async function makeInvoiceLink(invoiceId: string): Promise<string> {
  const expires = Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60;
  const token = await hmac(env("INVOICE_LINK_SECRET"), `${invoiceId}.${expires}`);
  return `${env("SUPABASE_URL")}/functions/v1/invoice-view?id=${encodeURIComponent(invoiceId)}&expires=${expires}&token=${token}`;
}
async function sendPaymentSms(admin: any, invoice: Invoice, profile: any, paymentRow: any) {
  const mobile = normalizeIndianMobile(profile?.phone);
  const link = await makeInvoiceLink(invoice.id);
  const { data: claimed, error: claimError } = await admin.rpc("claim_invoice_sms", { p_payment_id: paymentRow.id });
  if (claimError) throw claimError;
  if (!claimed) return { sms_sent: false, sms_already_processed: true };
  try {
    const payload = {
      template_id: env("MSG91_TEMPLATE_ID"),
      short_url: "0",
      realTimeResponse: "1",
      recipients: [{ mobiles: mobile, VAR1: invoice.invoice_number, VAR2: inr(invoice.amount_paise), VAR3: link }],
    };
    const response = await fetch("https://control.msg91.com/api/v5/flow", {
      method: "POST",
      headers: { authkey: env("MSG91_AUTH_KEY"), accept: "application/json", "content-type": "application/json", "Idempotency-Key": `ctech-payment-sms-${paymentRow.id}` },
      body: JSON.stringify(payload),
    });
    const responseText = await response.text();
    if (!response.ok) throw new Error(`MSG91 request failed (${response.status}): ${responseText.slice(0, 400)}`);
    let parsed: any = {}; try { parsed = JSON.parse(responseText); } catch { /* provider may return text */ }
    if (String(parsed?.type ?? "").toLowerCase() === "error" || parsed?.error) throw new Error(`MSG91 rejected SMS request: ${responseText.slice(0, 400)}`);
    const { error: updateError } = await admin.from("invoice_sms_deliveries").update({ status: "sent", sent_at: new Date().toISOString(), provider_response: responseText }).eq("payment_id", paymentRow.id).eq("status", "processing");
    if (updateError) throw updateError;
    return { sms_sent: true };
  } catch (e) {
    await admin.from("invoice_sms_deliveries").update({ status: "failed", last_error: String((e as Error)?.message ?? e) }).eq("payment_id", paymentRow.id).eq("status", "processing");
    throw e;
  }
}

async function sendInvoice(admin: any, paymentRow: any, enrollment: any, course: any, profile: any, paymentId: string) {
  const amountPaise = Number(paymentRow.amount_paise);
  const email = String(profile?.email || "").trim();
  if (!email) throw new Error("Student profile has no email address; invoice email cannot be sent");
  const customerName = [profile?.first_name, profile?.last_name].filter(Boolean).join(" ").trim() || "Student";
  const { data: existing, error: findErr } = await admin.from("invoice_records").select("*").eq("payment_id", paymentRow.id).maybeSingle();
  if (findErr) throw findErr;
  let invoice = existing as Invoice | null;
  if (!invoice) {
    const { data: made, error } = await admin.from("invoice_records").insert({ payment_id: paymentRow.id, razorpay_payment_id: paymentId, enrollment_id: enrollment.id, user_id: paymentRow.user_id, customer_name: customerName, customer_email: email, course_name: course.name, amount_paise: amountPaise, currency: paymentRow.currency || "INR" }).select("*").single();
    if (error && error.code !== "23505") throw error;
    if (made) invoice = made as Invoice;
    else { const again = await admin.from("invoice_records").select("*").eq("payment_id", paymentRow.id).single(); if (again.error) throw again.error; invoice = again.data as Invoice; }
  }
  // Atomic DB claim: only one concurrent request can own an unsent delivery.
  const { data: claimed, error: claimErr } = await admin.rpc("claim_invoice_email", { p_payment_id: paymentRow.id });
  if (claimErr) throw claimErr;
  if (!claimed) return { invoice_number: invoice!.invoice_number, email_sent: false, already_processed: true };
  try {
    const pdfBytes = await invoicePdf(invoice!); const html = invoiceHtml(invoice!);
    let binary = ""; for (let offset = 0; offset < pdfBytes.length; offset += 0x8000) binary += String.fromCharCode(...pdfBytes.subarray(offset, offset + 0x8000)); const pdfBase64 = btoa(binary);
    const resend = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${env("RESEND_API_KEY")}`, "Content-Type": "application/json", "Idempotency-Key": `ctech-invoice-${paymentRow.id}` }, body: JSON.stringify({ from: env("RESEND_FROM_EMAIL"), to: [invoice!.customer_email], subject: `Your CTech Cloud Academy invoice ${invoice!.invoice_number}`, html: `<p>Hello ${esc(invoice!.customer_name)},</p><p>Thank you for your payment. Your invoice is attached as a PDF and included below in HTML format.</p>${html}`, attachments: [{ filename: `${invoice!.invoice_number}.pdf`, content: pdfBase64 }] }) });
    const responseText = await resend.text();
    if (!resend.ok) throw new Error(`Resend request failed (${resend.status}): ${responseText.slice(0, 500)}`);
    const { error: updateErr } = await admin.from("invoice_email_deliveries").update({ status: "sent", sent_at: new Date().toISOString(), provider_response: responseText }).eq("payment_id", paymentRow.id).eq("status", "processing");
    if (updateErr) throw updateErr;
    return { invoice_number: invoice!.invoice_number, email_sent: true };
  } catch (e) {
    await admin.from("invoice_email_deliveries").update({ status: "failed", last_error: String((e as Error)?.message ?? e) }).eq("payment_id", paymentRow.id).eq("status", "processing");
    throw e;
  }
}
async function finalizePayment(admin: any, orderId: string, paymentId: string) {
  const { data: p, error: pErr } = await admin.from("payments").select("id,enrollment_id,user_id,razorpay_order_id,amount_paise,currency,status,razorpay_payment_id").eq("razorpay_order_id", orderId).maybeSingle();
  if (pErr) throw pErr; if (!p) throw new Error("Payment order is not present in Supabase");
  const response = await fetch(`https://api.razorpay.com/v1/payments/${encodeURIComponent(paymentId)}`, { headers: { Authorization: "Basic " + btoa(`${env("RAZORPAY_KEY_ID")}:${env("RAZORPAY_KEY_SECRET")}`) } });
  if (!response.ok) throw new Error(`Unable to verify payment with Razorpay (HTTP ${response.status})`);
  const rp = await response.json();
  if (rp.order_id !== orderId || Number(rp.amount) !== Number(p.amount_paise) || rp.currency !== (p.currency || "INR")) throw new Error("Razorpay payment does not match the stored order amount/currency");
  if (rp.status !== "captured") return { captured: false, status: rp.status };
  if (p.status === "paid" && p.razorpay_payment_id && p.razorpay_payment_id !== paymentId) throw new Error("This order is already associated with a different captured payment");
  if (p.status !== "paid") {
    const { error: upErr } = await admin.from("payments").update({ status: "paid", razorpay_payment_id: paymentId }).eq("id", p.id).neq("status", "paid");
    if (upErr) throw upErr;
    const { error: enErr } = await admin.from("enrollments").update({ status: "paid" }).eq("id", p.enrollment_id);
    if (enErr) throw enErr;
  }
  const [enrRes, courseRes, profileRes] = await Promise.all([
    admin.from("enrollments").select("id,course_id,user_id,status").eq("id", p.enrollment_id).single(),
    admin.from("enrollments").select("course_id").eq("id", p.enrollment_id).single().then((x: any) => x.error ? x : admin.from("courses").select("id,name").eq("id", x.data.course_id).single()),
    admin.from("profiles").select("id,first_name,last_name,email,phone").eq("id", p.user_id).single(),
  ]);
  if (enrRes.error) throw enrRes.error; if (courseRes.error) throw courseRes.error; if (profileRes.error) throw profileRes.error;
  let emailResult: any = { email_sent: false };
  let emailFailed = false;
  try {
    emailResult = await sendInvoice(admin, p, enrRes.data, courseRes.data, profileRes.data, paymentId);
  } catch (e) {
    emailFailed = true;
    console.error("Payment captured, but invoice email delivery failed:", e);
  }
  let smsResult: any = { sms_sent: false };
  try {
    const { data: invoice, error: invoiceError } = await admin.from("invoice_records").select("*").eq("payment_id", p.id).single();
    if (invoiceError || !invoice) throw invoiceError ?? new Error("Invoice record unavailable for SMS");
    smsResult = await sendPaymentSms(admin, invoice as Invoice, profileRes.data, p);
  } catch (smsError) {
    console.error("Payment captured, but SMS delivery failed:", smsError);
    smsResult = { sms_sent: false, sms_error: true };
  }
  return { captured: true, transaction_ref: paymentId, ...emailResult, ...smsResult, ...(emailFailed ? { email_error: true } : {}) };
}
async function handle(req: Request): Promise<Response> {
  const url = env("SUPABASE_URL"); const serviceKey = env("SUPABASE_SERVICE_ROLE_KEY");
  const admin = createClient(url, serviceKey);
  const webhookSig = req.headers.get("x-razorpay-signature");
  if (webhookSig) {
    const secret = env("RAZORPAY_WEBHOOK_SECRET"); const raw = await req.text();
    if (!safeEq(await hmac(secret, raw), webhookSig)) return json({ error: "Bad webhook signature" }, 400);
    let ev: any; try { ev = JSON.parse(raw); } catch { return json({ error: "Invalid webhook JSON" }, 400); }
    if (ev.event === "payment.captured") {
      const pay = ev.payload?.payment?.entity;
      if (!pay?.order_id || !pay?.id) return json({ error: "Webhook is missing payment identifiers" }, 400);
      const result = await finalizePayment(admin, pay.order_id, pay.id);
      if (!result.captured) return json({ ok: true, payment_status: result.status });
      if (result.email_error || result.sms_error) return json({ error: "Payment captured; one or more invoice notifications failed and webhook retry is requested.", ...result }, 500);
      return json({ ok: true, ...result });
    }
    if (ev.event === "payment.failed") {
      const pay = ev.payload?.payment?.entity;
      if (pay?.order_id) { const { error } = await admin.from("payments").update({ status: "failed" }).eq("razorpay_order_id", pay.order_id).eq("status", "created"); if (error) throw error; }
    }
    return json({ ok: true, ignored_event: ev.event });
  }
  const secret = env("RAZORPAY_KEY_SECRET");
  const authed = createClient(url, env("SUPABASE_ANON_KEY"), { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
  const { data: { user } } = await authed.auth.getUser(); if (!user) return json({ error: "Not authenticated" }, 401);
  const body = await req.json().catch(() => ({})); const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = body;
  if (![razorpay_order_id, razorpay_payment_id, razorpay_signature].every((x: unknown) => typeof x === "string" && x.length > 0)) return json({ error: "Missing payment verification fields" }, 400);
  const { data: own, error: ownErr } = await admin.from("payments").select("id").eq("razorpay_order_id", razorpay_order_id).eq("user_id", user.id).maybeSingle();
  if (ownErr) throw ownErr; if (!own) return json({ error: "Order not found for this user" }, 404);
  if (!safeEq(await hmac(secret, `${razorpay_order_id}|${razorpay_payment_id}`), razorpay_signature)) return json({ error: "Signature verification failed" }, 400);
  const result = await finalizePayment(admin, razorpay_order_id, razorpay_payment_id);
  if (!result.captured) return json({ ok: true, payment_status: result.status, message: "Payment is not captured yet; enrollment remains pending confirmation." }, 202);
  return json({ ok: true, ...result });
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try { return await handle(req); }
  catch (e) { console.error("verify-payment failed:", e); return json({ error: "Payment verification or invoice delivery failed. Check Edge Function logs." }, 500); }
});

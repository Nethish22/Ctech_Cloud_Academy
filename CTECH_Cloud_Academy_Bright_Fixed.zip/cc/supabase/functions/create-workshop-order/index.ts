import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const workshops: Record<string, string> = {
  "excel-data-analytics": "Excel & Data Analytics",
  "sql-fundamentals": "SQL Fundamentals",
  "power-bi-dashboard-basics": "Power BI Dashboard Basics",
  "python-eda": "Python & EDA",
  "cloud-data-engineering": "Cloud & Data Engineering",
  "ai-apis-fde": "AI, APIs & FDE Introduction"
};
async function handle(req: Request) {
  const keyId = Deno.env.get("RAZORPAY_KEY_ID"), keySecret = Deno.env.get("RAZORPAY_KEY_SECRET");
  if (!keyId || !keySecret) return json({ error: "Razorpay credentials are not configured in Supabase secrets." }, 503);
  const url = Deno.env.get("SUPABASE_URL")!;
  const anon = Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!;
  const authHeader = req.headers.get("Authorization") || "";
  const client = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
  const { data: { user }, error: userError } = await client.auth.getUser();
  if (userError || !user) return json({ error: "Please log in before paying for a workshop." }, 401);
  const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { workshop_slug } = await req.json().catch(() => ({}));
  const title = workshops[String(workshop_slug || "")];
  if (!title) return json({ error: "Unknown workshop." }, 400);
  const amount = 49900; // ₹499 fixed on the server; never trust a browser-supplied amount.
  const orderResponse = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST", headers: { "Content-Type": "application/json", Authorization: "Basic " + btoa(`${keyId}:${keySecret}`) },
    body: JSON.stringify({ amount, currency: "INR", receipt: `ws_${crypto.randomUUID().replaceAll("-", "").slice(0, 28)}`, notes: { user_id: user.id, workshop_slug, workshop_title: title } })
  });
  const orderText = await orderResponse.text(); let order: any = {}; try { order = JSON.parse(orderText); } catch { /* handled below */ }
  if (!orderResponse.ok || !order.id) { console.error("Razorpay workshop order creation failed", orderText); return json({ error: "Razorpay could not create the workshop order. Please retry." }, 502); }
  const { error } = await admin.from("workshop_payments").insert({ user_id: user.id, workshop_slug, workshop_title: title, amount_paise: amount, currency: "INR", razorpay_order_id: order.id, status: "created" });
  if (error) { console.error("Could not persist workshop payment", error); return json({ error: "Could not save the workshop payment record. Please contact the academy before retrying." }, 500); }
  return json({ order_id: order.id, amount, currency: "INR", key_id: keyId, workshop_title: title });
}
Deno.serve(async req => { if (req.method === "OPTIONS") return new Response("ok", { headers: cors }); if (req.method !== "POST") return json({ error: "Method not allowed" }, 405); try { return await handle(req); } catch (e) { console.error(e); return json({ error: "Workshop checkout failed unexpectedly." }, 500); } });

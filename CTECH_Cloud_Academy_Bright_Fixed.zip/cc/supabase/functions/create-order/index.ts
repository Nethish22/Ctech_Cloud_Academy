import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

async function handle(req: Request): Promise<Response> {
  const keyId = Deno.env.get("RAZORPAY_KEY_ID"), keySecret = Deno.env.get("RAZORPAY_KEY_SECRET");
  if (!keyId || !keySecret) return json({ error: "Razorpay credentials are not configured (development mode)." }, 503);

  const url = Deno.env.get("SUPABASE_URL")!;
  const authed = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
  const { data: { user } } = await authed.auth.getUser();
  if (!user) return json({ error: "Not authenticated" }, 401);

  const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { course_id, learning_mode } = await req.json().catch(() => ({}));
  if (!course_id) return json({ error: "course_id required" }, 400);

  // price comes from the database only
  const { data: course } = await admin.from("courses").select("id,name,fee_inr,discount_inr").eq("id", course_id).eq("is_published", true).single();
  if (!course) return json({ error: "Course not available" }, 404);
  const amount = (course.fee_inr - course.discount_inr) * 100;
  if (amount < 100) return json({ error: "Invalid course price" }, 400);

  let { data: enr } = await admin.from("enrollments").select("id,status").eq("user_id", user.id).eq("course_id", course_id).maybeSingle();
  if (enr?.status === "paid") return json({ error: "Already enrolled" }, 409);
  if (!enr) {
    const ins = await admin.from("enrollments").insert({ user_id: user.id, course_id, learning_mode, status: "pending" }).select("id,status").single();
    enr = ins.data;
  }

  const rz = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Basic " + btoa(`${keyId}:${keySecret}`) },
    body: JSON.stringify({ amount, currency: "INR", receipt: enr!.id.slice(0, 40), notes: { enrollment_id: enr!.id } }),
  });
  if (!rz.ok) return json({ error: "Could not create payment order" }, 502);
  const order = await rz.json();

  // Do not return a Razorpay order to the browser unless its matching payment row
  // was successfully persisted. Otherwise verification/receipt lookup cannot find it.
  const { error: paymentInsertError } = await admin.from("payments").insert({
    enrollment_id: enr!.id,
    user_id: user.id,
    razorpay_order_id: order.id,
    amount_paise: amount,
    currency: order.currency || "INR",
    status: "created"
  });
  if (paymentInsertError) {
    console.error("Failed to save payment row for Razorpay order:", paymentInsertError);
    // The Razorpay order exists but is not safely usable by this app; do not proceed.
    return json({ error: "Could not save the payment transaction. Please retry or contact support." }, 500);
  }
  const { error: enrollmentUpdateError } = await admin.from("enrollments").update({ status: "payment_pending" }).eq("id", enr!.id);
  if (enrollmentUpdateError) {
    console.error("Failed to update enrollment payment status:", enrollmentUpdateError);
    return json({ error: "Could not update enrollment status. Please contact support before retrying payment." }, 500);
  }
  return json({ order_id: order.id, amount, currency: "INR", key_id: keyId, course_name: course.name });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try { return await handle(req); }
  catch (e) { console.error("function crashed:", e); return json({ error: "Server error: " + ((e as Error)?.message ?? String(e)) }, 500); }
});

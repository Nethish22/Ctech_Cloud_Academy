import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const env = (k: string) => { const v = Deno.env.get(k); if (!v) throw new Error(`Missing server secret: ${k}`); return v; };
async function hmac(secret: string, message: string) { const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]); const bytes = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message))); return [...bytes].map(b => b.toString(16).padStart(2, "0")).join(""); }
function safeEqual(a: string, b: string) { if (a.length !== b.length) return false; let diff = 0; for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i); return diff === 0; }
async function handle(req: Request) {
  const url = env("SUPABASE_URL"), anon = Deno.env.get("SUPABASE_ANON_KEY") || env("SUPABASE_PUBLISHABLE_KEY");
  const client = createClient(url, anon, { global: { headers: { Authorization: req.headers.get("Authorization") || "" } } });
  const { data: { user }, error: authError } = await client.auth.getUser(); if (authError || !user) return json({ error: "Not authenticated" }, 401);
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json().catch(() => ({}));
  if (![razorpay_order_id, razorpay_payment_id, razorpay_signature].every(v => typeof v === "string" && v.length > 0)) return json({ error: "Missing Razorpay verification fields" }, 400);
  const admin = createClient(url, env("SUPABASE_SERVICE_ROLE_KEY"));
  const { data: row, error } = await admin.from("workshop_payments").select("id,user_id,workshop_title,amount_paise,currency,status,razorpay_order_id,razorpay_payment_id").eq("razorpay_order_id", razorpay_order_id).maybeSingle();
  if (error) throw error; if (!row || row.user_id !== user.id) return json({ error: "Workshop order not found for this account" }, 404);
  if (row.status === "paid" && row.razorpay_payment_id === razorpay_payment_id) return json({ captured: true, workshop_title: row.workshop_title, already_verified: true });
  const expected = await hmac(env("RAZORPAY_KEY_SECRET"), `${razorpay_order_id}|${razorpay_payment_id}`);
  if (!safeEqual(expected, String(razorpay_signature))) return json({ error: "Payment signature verification failed" }, 400);
  const response = await fetch(`https://api.razorpay.com/v1/payments/${encodeURIComponent(razorpay_payment_id)}`, { headers: { Authorization: "Basic " + btoa(`${env("RAZORPAY_KEY_ID")}:${env("RAZORPAY_KEY_SECRET")}`) } });
  if (!response.ok) return json({ error: "Could not verify payment status with Razorpay" }, 502);
  const payment = await response.json();
  if (payment.order_id !== razorpay_order_id || Number(payment.amount) !== Number(row.amount_paise) || payment.currency !== row.currency) return json({ error: "Payment details do not match this workshop order" }, 400);
  if (payment.status !== "captured") return json({ captured: false, status: payment.status, workshop_title: row.workshop_title });
  const { error: updateError } = await admin.from("workshop_payments").update({ status: "paid", razorpay_payment_id }).eq("id", row.id).eq("user_id", user.id);
  if (updateError) throw updateError;
  return json({ captured: true, workshop_title: row.workshop_title, amount_paise: row.amount_paise, razorpay_payment_id });
}
Deno.serve(async req => { if (req.method === "OPTIONS") return new Response("ok", { headers: cors }); if (req.method !== "POST") return json({ error: "Method not allowed" }, 405); try { return await handle(req); } catch (e) { console.error(e); return json({ error: "Workshop verification failed. Contact support if money was deducted." }, 500); } });

-- CTECH Cloud Academy: ONE-SHOT SETUP (tables + security + 33 placeholder courses).
-- Paste all of this into Supabase > SQL Editor > New query > Run. Safe to re-run.

-- CTECH Cloud Academy schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text not null, last_name text not null, email text,
  phone text, preferred_course text,
  learning_mode text check (learning_mode in ('online','offline')),
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz default now(), updated_at timestamptz default now()
);

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null, name text not null, category text not null,
  description text, duration text, delivery_mode text, skill_level text,
  curriculum jsonb default '[]', prerequisites text, projects text,
  fee_inr integer not null check (fee_inr >= 0),        -- placeholder until real fees
  discount_inr integer not null default 0 check (discount_inr >= 0),
  is_published boolean not null default false,
  created_at timestamptz default now(), updated_at timestamptz default now(),
  check (discount_inr <= fee_inr)
);

create table if not exists public.enrollments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid not null references public.courses(id),
  status text not null default 'pending'
    check (status in ('pending','payment_pending','paid','failed','cancelled','refunded')),
  learning_mode text, created_at timestamptz default now(), updated_at timestamptz default now(),
  unique (user_id, course_id)
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  enrollment_id uuid not null references public.enrollments(id) on delete cascade,
  user_id uuid not null references public.profiles(id),
  razorpay_order_id text unique not null,
  razorpay_payment_id text unique,
  amount_paise integer not null, currency text not null default 'INR',
  status text not null default 'created' check (status in ('created','paid','failed','refunded')),
  created_at timestamptz default now(), updated_at timestamptz default now()
);

create table if not exists public.contact_enquiries (
  id uuid primary key default gen_random_uuid(),
  full_name text not null check (char_length(full_name) between 2 and 100),
  email text not null check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  phone text, course_interest text, learning_mode text,
  subject text not null check (char_length(subject) <= 150),
  message text not null check (char_length(message) between 5 and 2000),
  status text not null default 'new', created_at timestamptz default now()
);

create index if not exists idx_ctech_1 on public.enrollments (user_id);
create index if not exists idx_ctech_2 on public.payments (user_id);
create index if not exists idx_ctech_3 on public.payments (enrollment_id);
create index if not exists idx_ctech_4 on public.courses (is_published, category);

-- helpers
create or replace function public.is_admin() returns boolean
language sql security definer set search_path = public stable as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;

create or replace function public.touch() returns trigger language plpgsql as
$$ begin new.updated_at = now(); return new; end $$;
drop trigger if exists t1 on profiles;
create trigger t1 before update on profiles for each row execute function touch();
drop trigger if exists t2 on courses;
create trigger t2 before update on courses for each row execute function touch();
drop trigger if exists t3 on enrollments;
create trigger t3 before update on enrollments for each row execute function touch();
drop trigger if exists t4 on payments;
create trigger t4 before update on payments for each row execute function touch();

-- block self-promotion: role changes only via SQL editor / service role
create or replace function public.protect_role() returns trigger
language plpgsql as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null then
    raise exception 'role cannot be changed from the client';
  end if;
  return new;
end $$;
drop trigger if exists protect_role on profiles;
create trigger protect_role before update on profiles for each row execute function protect_role();

-- create profile on signup (role always 'student')
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, first_name, last_name, phone, preferred_course, learning_mode)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'first_name',''),
    coalesce(new.raw_user_meta_data->>'last_name',''), new.raw_user_meta_data->>'phone',
    new.raw_user_meta_data->>'preferred_course', new.raw_user_meta_data->>'learning_mode');
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- RLS
alter table profiles enable row level security;
alter table courses enable row level security;
alter table enrollments enable row level security;
alter table payments enable row level security;
alter table contact_enquiries enable row level security;

drop policy if exists "own profile read" on profiles;
create policy "own profile read" on profiles for select using (id = auth.uid() or is_admin());
drop policy if exists "own profile update" on profiles;
create policy "own profile update" on profiles for update using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "public read published" on courses;
create policy "public read published" on courses for select using (is_published or is_admin());
drop policy if exists "admin manage courses" on courses;
create policy "admin manage courses" on courses for all using (is_admin()) with check (is_admin());

drop policy if exists "own enrollments read" on enrollments;
create policy "own enrollments read" on enrollments for select using (user_id = auth.uid() or is_admin());
drop policy if exists "admin update enrollments" on enrollments;
create policy "admin update enrollments" on enrollments for update using (is_admin());
-- no student insert/update: enrollments are created by the create-order Edge Function (service role)

drop policy if exists "own payments read" on payments;
create policy "own payments read" on payments for select using (user_id = auth.uid() or is_admin());
-- no client insert/update on payments: only Edge Functions (service role) write

drop policy if exists "anyone can submit enquiry" on contact_enquiries;
create policy "anyone can submit enquiry" on contact_enquiries for insert to anon, authenticated with check (status = 'new');
drop policy if exists "admin read enquiries" on contact_enquiries;
create policy "admin read enquiries" on contact_enquiries for select using (is_admin());
drop policy if exists "admin update enquiries" on contact_enquiries;
create policy "admin update enquiries" on contact_enquiries for update using (is_admin());

-- First admin: sign up normally, then run (replace the email):
-- update public.profiles set role='admin' where id=(select id from auth.users where email='you@example.com');

-- Audit log for enrollment status changes
create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(), actor uuid, action text not null,
  entity text, entity_id uuid, details jsonb, created_at timestamptz default now());
alter table audit_log enable row level security;
drop policy if exists "admin read audit" on audit_log;
create policy "admin read audit" on audit_log for select using (is_admin());
create or replace function public.log_enrollment() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into audit_log(actor, action, entity, entity_id, details)
  values (auth.uid(), 'enrollment_status_change', 'enrollments', new.id,
          jsonb_build_object('from', old.status, 'to', new.status));
  return new;
end $$;
drop trigger if exists enrollment_audit on enrollments;
create trigger enrollment_audit after update on enrollments
  for each row when (old.status is distinct from new.status) execute function log_enrollment();


-- Placeholder catalog. Fees (INR 10000) are PLACEHOLDERS: edit them in Admin > Courses.
insert into public.courses (slug,name,category,description,duration,delivery_mode,skill_level,prerequisites,projects,fee_inr,is_published)
select trim(both '-' from lower(regexp_replace(name,'[^a-zA-Z0-9]+','-','g'))), name, cat,
 'Course description to be added by the academy.', '[Duration to be confirmed]', 'Online / Offline', 'Beginner to Intermediate',
 'To be confirmed', 'Hands-on project details to be confirmed', 10000, true
from (values
('Data Engineering','Azure Data Engineering'),('Data Engineering','AWS Data Engineering'),('Data Engineering','Databricks'),
('Data Engineering','Apache Spark and PySpark'),('Data Engineering','SQL and Advanced SQL'),('Data Engineering','Data Warehousing'),
('Data Engineering','ETL/ELT Pipelines'),('Data Engineering','Microsoft Fabric'),
('Data Analytics','Data Analytics with Excel'),('Data Analytics','SQL for Data Analytics'),('Data Analytics','Power BI'),
('Data Analytics','Python for Data Analytics'),('Data Analytics','Tableau'),('Data Analytics','Business Intelligence'),
('Cloud Computing','Azure Fundamentals'),('Cloud Computing','Azure Administrator'),('Cloud Computing','Azure Data Services'),
('Cloud Computing','AWS Cloud Fundamentals'),('Cloud Computing','AWS Solutions Architecture'),('Cloud Computing','Cloud Security'),
('Cloud Computing','DevOps and CI/CD'),('Cloud Computing','Kubernetes and Docker'),
('AI & Machine Learning','Python Programming'),('AI & Machine Learning','Machine Learning'),('AI & Machine Learning','Artificial Intelligence'),
('AI & Machine Learning','Generative AI Fundamentals'),('AI & Machine Learning','Data Science'),
('Full-Stack & Technology Stacks','HTML, CSS and JavaScript'),('Full-Stack & Technology Stacks','React'),
('Full-Stack & Technology Stacks','Python Development'),('Full-Stack & Technology Stacks','Java Development'),
('Full-Stack & Technology Stacks','Node.js and APIs'),('Full-Stack & Technology Stacks','SQL and Database Development'),
('Full-Stack & Technology Stacks','.NET Development')
) v(cat,name)
on conflict (slug) do nothing;

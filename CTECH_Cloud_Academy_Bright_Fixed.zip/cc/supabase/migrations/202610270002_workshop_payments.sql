-- Workshop checkout records. Run this migration in Supabase SQL Editor before deploying functions.
create table if not exists public.workshop_payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  workshop_slug text not null,
  workshop_title text not null,
  amount_paise integer not null default 49900 check (amount_paise = 49900),
  currency text not null default 'INR' check (currency = 'INR'),
  razorpay_order_id text unique not null,
  razorpay_payment_id text unique,
  status text not null default 'created' check (status in ('created','paid','failed','refunded')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists workshop_payments_user_id_idx on public.workshop_payments(user_id);
create index if not exists workshop_payments_slug_idx on public.workshop_payments(workshop_slug);
alter table public.workshop_payments enable row level security;
drop policy if exists "students read own workshop payments" on public.workshop_payments;
create policy "students read own workshop payments" on public.workshop_payments
  for select to authenticated using (user_id = auth.uid() or public.is_admin());
drop trigger if exists workshop_payments_touch on public.workshop_payments;
create trigger workshop_payments_touch before update on public.workshop_payments
  for each row execute function public.touch();
-- No client-side insert/update policy: only the server-side Edge Functions write payment state.

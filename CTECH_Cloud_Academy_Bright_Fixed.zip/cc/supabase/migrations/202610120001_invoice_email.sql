-- CTech Cloud Academy: invoice snapshots + idempotent Resend delivery tracking.
-- Apply once in Supabase SQL Editor after backing up production data.
create table if not exists public.invoice_records (
  id uuid primary key default gen_random_uuid(),
  invoice_number text not null unique default ('CTECH-' || to_char(now() at time zone 'Asia/Kolkata', 'YYYYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  payment_id uuid not null unique references public.payments(id) on delete restrict,
  razorpay_payment_id text not null unique,
  enrollment_id uuid not null references public.enrollments(id) on delete restrict,
  user_id uuid not null references public.profiles(id) on delete restrict,
  customer_name text not null,
  customer_email text not null,
  course_name text not null,
  amount_paise integer not null check (amount_paise > 0),
  currency text not null default 'INR' check (currency = 'INR'),
  issued_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.invoice_email_deliveries (
  payment_id uuid primary key references public.payments(id) on delete restrict,
  status text not null default 'processing' check (status in ('processing','sent','failed')),
  sent_at timestamptz,
  provider_response text,
  last_error text,
  updated_at timestamptz not null default now()
);

alter table public.invoice_records enable row level security;
alter table public.invoice_email_deliveries enable row level security;
-- No client policies: only Edge Functions using the service-role key can read/write these tables.

create or replace function public.claim_invoice_email(p_payment_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare claimed uuid;
begin
  insert into public.invoice_email_deliveries(payment_id, status, updated_at)
  values (p_payment_id, 'processing', now())
  on conflict (payment_id) do update
    set status = 'processing', last_error = null, updated_at = now()
    where public.invoice_email_deliveries.status = 'failed'
  returning payment_id into claimed;
  return claimed is not null;
end;
$$;
revoke all on function public.claim_invoice_email(uuid) from public, anon, authenticated;
grant execute on function public.claim_invoice_email(uuid) to service_role;

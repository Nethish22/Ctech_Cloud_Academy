-- CTech Cloud Academy: idempotent MSG91 SMS delivery tracking.
-- MSG91 SMS delivery tracking is separate from email so one channel can fail independently.
create table if not exists public.invoice_sms_deliveries (
  payment_id uuid primary key references public.payments(id) on delete restrict,
  status text not null default 'processing' check (status in ('processing','sent','failed')),
  sent_at timestamptz,
  provider_response text,
  last_error text,
  updated_at timestamptz not null default now()
);
alter table public.invoice_sms_deliveries enable row level security;

create or replace function public.claim_invoice_sms(p_payment_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare claimed uuid;
begin
  insert into public.invoice_sms_deliveries(payment_id, status, updated_at)
  values (p_payment_id, 'processing', now())
  on conflict (payment_id) do update
    set status = 'processing', last_error = null, updated_at = now()
    where public.invoice_sms_deliveries.status = 'failed'
  returning payment_id into claimed;
  return claimed is not null;
end;
$$;
revoke all on function public.claim_invoice_sms(uuid) from public, anon, authenticated;
grant execute on function public.claim_invoice_sms(uuid) to service_role;
